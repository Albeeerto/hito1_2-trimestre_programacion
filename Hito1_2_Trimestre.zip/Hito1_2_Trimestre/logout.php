<?php
// Iniciar la sesión si no se ha iniciado
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Destruir la sesión
session_destroy();

// Eliminar las cookies
setcookie("user_id", "", time() - 3600, "/"); // 3600 = 1 hora
setcookie("user_key", "", time() - 3600, "/");

// Redirigir al usuario a la página de inicio de sesión
header("Location: login.php");
exit;
?>