<?php
include_once 'functions.php';
check_user_logged_in();

// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Recibir los datos del formulario
$email = $_POST['email'];
$title = $_POST['title'];
$content = $_POST['content'];
$publish_date = $_POST['publish_date'];
$image = $_POST['image']; // Aquí recibimos la URL de la imagen

// Validar los datos (aquí puedes agregar más validaciones si lo deseas)
if (empty($email) || empty($title) || empty($content) || empty($publish_date) || empty($image)) {
    die("Por favor, completa todos los campos.");
}

// Preparar la consulta SQL para insertar la nueva entrada
$stmt = $mysqli->prepare("INSERT INTO posts (email, title, content, publish_date, image) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param('sssss', $email, $title, $content, $publish_date, $image);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo "Tu entrada ha sido publicada.";
} else {
    echo "Hubo un error al publicar tu entrada.";
}

// Cerrar la conexión
$mysqli->close();
?>