<?php
// Almacenar la IP del usuario y la fecha de acceso en una cookie
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d H:i:s');
setcookie('ip', $ip, time() + (86400 * 30), "/"); // 86400 = 1 día
setcookie('date', $date, time() + (86400 * 30), "/");

// Incluir el texto explicativo
?>
<!DOCTYPE html>
<html>
<head>
    <title>Inicio</title>
    <!-- CSS de Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Mi Blog</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_post.php">Ver entradas</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php">Crear entradas</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="register.php">Registro</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">iniciar sesion</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container">
    <h1 class="my-4">Bienvenido</h1>
    <p>
        Aquí va la explicación de las diferencias entre lenguajes de programación orientada a objetos, a eventos y lenguajes procedimentales:
        <br>
        <br>
        <strong>Procedimental:</strong> En la programación procedimental, el énfasis está en los procedimientos o funciones que manipulan los datos. El código se organiza en una secuencia de instrucciones, donde se definen funciones que realizan tareas específicas. Los datos se pasan entre estas funciones como parámetros, y las variables pueden tener un alcance global o local. Ejemplos de lenguajes procedimentales son C y Pascal.
        <br>
        <strong>Orientada a Objetos:</strong> La programación orientada a objetos (POO) se basa en el concepto de "objetos", que son entidades que contienen datos en forma de atributos y procedimientos en forma de métodos. Estos objetos interactúan entre sí mediante el intercambio de mensajes. La POO se centra en la encapsulación, la herencia y el polimorfismo como principios fundamentales. Ejemplos de lenguajes orientados a objetos son Java, Python y C++.
        <br>
        <strong>Basada en Eventos:</strong>En la programación basada en eventos, el flujo de control del programa está determinado por eventos que ocurren en el sistema, como clics de ratón, pulsaciones de teclas o temporizadores. El programa responde a estos eventos ejecutando ciertas acciones o manejadores de eventos asociados a cada evento. Este enfoque es común en el desarrollo de interfaces de usuario y aplicaciones que requieren una respuesta en tiempo real. Ejemplos de lenguajes que admiten programación basada en eventos incluyen JavaScript (para desarrollo web), Visual Basic y C# (para desarrollo de aplicaciones de escritorio).
    </p>
    <img src="https://p.calameoassets.com/171127195320-4c47984c80f62d66b504856de10f6bb6/p1.jpg" class="img-fluid" alt="Programación orientada a objetos">
</div>
<!-- JS de Bootstrap -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
