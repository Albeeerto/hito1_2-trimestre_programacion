<?php
include_once 'functions.php';
check_user_logged_in();

// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Recibir el ID del post a eliminar
$id = $_GET['id'];

// Preparar la consulta SQL para eliminar el post
$stmt = $mysqli->prepare("DELETE FROM posts WHERE id = ?");
$stmt->bind_param('i', $id);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo "La entrada ha sido eliminada.";
} else {
    echo "Hubo un error al eliminar la entrada.";
}

// Cerrar la conexión
$mysqli->close();

// Redirigir al usuario a la página de visualización de posts
header('Location: view_post.php');
?>