

<?php
// Incluir las funciones necesarias
include_once 'functions.php';

// Verificar si el usuario ha iniciado sesión
check_user_logged_in();

// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Obtener los valores del formulario
$username = $_POST['name'];
$email = $_POST['email'];

// Obtener el ID del usuario logueado
$user_id = $_SESSION['user_id'];

// Preparar la consulta SQL para actualizar la información del usuario
$stmt = $mysqli->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
$stmt->bind_param('ssi', $name, $email, $user_id);

// Ejecutar la consulta
$stmt->execute();

// Cerrar la conexión
$mysqli->close();

// Redirigir al usuario a la página de perfil
header('Location: profile.php');
?>

