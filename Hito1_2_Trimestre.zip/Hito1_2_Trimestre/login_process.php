<?php
// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Recibir los datos del formulario
$email = $_POST['email'];
$password = $_POST['password'];

// Preparar la consulta SQL para obtener la información del usuario
$stmt = $mysqli->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param('s', $email);

// Ejecutar la consulta
$stmt->execute();

// Obtener los resultados
$result = $stmt->get_result();

// Comprobar si se encontró el usuario
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Comprobar la contraseña
    if (password_verify($password, $user['password'])) {
        // Iniciar la sesión
        session_start();
        $_SESSION['user_id'] = $user['id'];

        // Establecer las cookies para recordar al usuario
        setcookie("user_id", $user['id'], time() + (86400 * 30), "/"); // 86400 = 1 día
        setcookie("user_key", hash('sha256', $user['password']), time() + (86400 * 30), "/");

        // Redirigir al usuario a la página de inicio
        header("Location: inicio.php");
        exit;
    } else {
        echo "La contraseña es incorrecta.";
    }
} else {
    echo "No se encontró el usuario.";
}

// Cerrar la conexión
$mysqli->close();
?>