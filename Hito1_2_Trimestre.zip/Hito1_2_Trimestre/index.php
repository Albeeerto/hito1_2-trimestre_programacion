<!DOCTYPE html>
<html>
<head>
    <title>Publicar entrada</title>
    <!-- CSS de Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Mi Blog</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item ">
                <a class="nav-link" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_post.php">Ver entradas</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Crear entradas</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="register.php">Registro</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">iniciar sesion</a>
            </li>
        </ul>
    </div>
</nav>
<form action="publish.php" method="post" enctype="multipart/form-data">
    <div class="container">
    <h1 class="my-4">Publicar entrada</h1>
    <form action="publish.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="title">Título:</label>
            <input type="text" id="title" name="title" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="content">Contenido:</label>
            <textarea id="content" name="content" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label for="publish_date">Fecha de publicación:</label>
            <input type="date" id="publish_date" name="publish_date" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="image">Imagen:</label>
            <input type="text" id="image" name="image" class="form-control" placeholder="Introduce la URL de la imagen" required>
        </div>
        <input type="submit" value="Publicar" class="btn btn-primary">
    </form>
</div>
<!-- JS de Bootstrap -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>