<?php
include 'functions.php';
check_user_logged_in();

// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Preparar la consulta SQL para obtener la información del usuario
$stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);

// Ejecutar la consulta
$stmt->execute();

// Obtener los resultados
$result = $stmt->get_result();

// Comprobar si se encontró el usuario
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("No se encontró el usuario.");
}

// Cerrar la conexión
$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar perfil</title>
    <!-- CSS de Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="my-4">Editar perfil</h1>
    <form action="update_profile.php" method="post">
        <div class="form-group">
            <label for="username">Nombre de usuario</label>
            <input type="text" class="form-control" id="username" name="username" value="<?= $user['username'] ?>">
        </div>
        <div class="form-group">
            <label for="email">Correo electrónico</label>
            <input type="email" id="email" name="email" class="form-control" value="<?= $user['email'] ?>">
        </div>
        <button type="submit" class="btn btn-primary">Actualizar perfil</button>
        <a href="logout.php" class="btn btn-secondary">Cerrar sesión</a>
    </form>
</div>
<!-- JS de Bootstrap -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>