<?php
include_once 'functions.php';
check_user_logged_in();

// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Recibir los datos del formulario
$id = $_POST['id'];
$title = $_POST['title'];
$content = $_POST['content'];
$publish_date = $_POST['publish_date'];
$image = $_POST['image']; // Ahora es una URL

// Preparar la consulta SQL para actualizar la entrada
$stmt = $mysqli->prepare("UPDATE posts SET title = ?, content = ?, publish_date = ?, image = ? WHERE id = ?");
$stmt->bind_param('ssssi', $title, $content, $publish_date, $image, $id);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo "La entrada ha sido actualizada.";
} else {
    echo "Hubo un error al actualizar la entrada.";
}

// Cerrar la conexión
$mysqli->close();
?>