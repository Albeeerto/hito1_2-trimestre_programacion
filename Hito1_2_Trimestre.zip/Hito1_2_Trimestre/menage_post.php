<?php
// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Preparar la consulta SQL
$stmt = $mysqli->prepare("SELECT * FROM posts ORDER BY publish_date DESC");

// Ejecutar la consulta
$stmt->execute();

// Obtener los resultados
$result = $stmt->get_result();

// Cerrar la conexión
$mysqli->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Gestionar entradas</title>
    <!-- CSS de Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="my-4">Gestionar entradas</h1>
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="card mb-4">
            <div class="card-body">
                <h2 class="card-title"><?= $row['title'] ?></h2>
                <p class="card-text"><?= $row['content'] ?></p>
                <p class="card-text"><small class="text-muted">Publicado por <?= $row['email'] ?> el <?= $row['publish_date'] ?></small></p>
            </div>
            <?php if (!empty($row['image'])): ?>
                <img src="<?= $row['image'] ?>" class="card-img-bottom" alt="Imagen de la entrada">
            <?php endif; ?>
            <div class="card-footer">
                <a href="update_post.php?id=<?= $row['id'] ?>" class="btn btn-primary">Actualizar</a>
                <a href="delete_post.php?id=<?= $row['id'] ?>" class="btn btn-danger">Eliminar</a>
            </div>
        </div>
    <?php endwhile; ?>
</div>
<!-- JS de Bootstrap -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>