<?php
// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Recibir los datos del formulario
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

// Validar los datos (aquí puedes agregar más validaciones si lo deseas)
if (empty($name) || empty($email) || empty($password)) {
    die("Por favor, completa todos los campos.");
}

// Preparar la consulta SQL para insertar el nuevo usuario
$stmt = $mysqli->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$stmt->bind_param('sss', $name, $email, $hashed_password);
// Ejecutar la consulta
if ($stmt->execute()) {
    echo "Te has registrado correctamente.";
} else {
    echo "Hubo un error al registrarte.";
}

// Cerrar la conexión
$mysqli->close();
?>