<?php
// Conectar a la base de datos
$mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

// Comprobar la conexión
if ($mysqli->connect_error) {
    die("La conexión falló: " . $mysqli->connect_error);
}

// Obtener el ID de la entrada a actualizar
$id = $_GET['id'];

// Preparar la consulta SQL para obtener los datos actuales de la entrada
$stmt = $mysqli->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->bind_param('i', $id);

// Ejecutar la consulta
$stmt->execute();

// Obtener los resultados
$result = $stmt->get_result();

// Comprobar si se encontró la entrada
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("No se encontró la entrada con el ID especificado.");
}

// Cerrar la conexión
$mysqli->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Actualizar entrada</title>
    <!-- CSS de Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="my-4">Actualizar entrada</h1>
    <form action="update_post_process.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Título:</label>
            <input type="text" id="title" name="title" class="form-control" value="<?= $row['title'] ?>" required>
        </div>
        <div class="form-group">
            <label for="content">Contenido:</label>
            <textarea id="content" name="content" class="form-control" required><?= $row['content'] ?></textarea>
        </div>
        <div class="form-group">
            <label for="publish_date">Fecha de publicación:</label>
            <input type="date" id="publish_date" name="publish_date" class="form-control" value="<?= $row['publish_date'] ?>" required>
        </div>
        <div class="form-group">
            <label for="image">Imagen:</label>
            <input type="text" id="image" name="image" class="form-control" placeholder="Ingrese la URL de la imagen" value="<?= $row['image'] ?>" required>
        </div>
        <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <input type="submit" value="Actualizar" class="btn btn-primary">
    </form>
</div>
<!-- JS de Bootstrap -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>