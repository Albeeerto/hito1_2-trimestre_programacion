<?php
include_once 'functions.php';
function check_user_logged_in() {
    // Iniciar la sesión si no se ha iniciado
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    // Comprobar si el usuario ha iniciado sesión
    if (!isset($_SESSION['user_id'])) {
        // Si el usuario no ha iniciado sesión, comprobar las cookies
        if (isset($_COOKIE['user_id']) && isset($_COOKIE['user_key'])) {
            // Conectar a la base de datos
            $mysqli = new mysqli('localhost', 'root', 'curso', 'blog');

            // Comprobar la conexión
            if ($mysqli->connect_error) {
                die("La conexión falló: " . $mysqli->connect_error);
            }

            // Preparar la consulta SQL para obtener la información del usuario
            $stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->bind_param('i', $_COOKIE['user_id']);

            // Ejecutar la consulta
            $stmt->execute();

            // Obtener los resultados
            $result = $stmt->get_result();

            // Comprobar si se encontró el usuario
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();

                // Comprobar si la clave de la cookie coincide con la clave del usuario
                if ($_COOKIE['user_key'] == hash('sha256', $user['password'])) {
                    // Si la clave coincide, iniciar la sesión
                    $_SESSION['user_id'] = $user['id'];
                }
            }

            // Cerrar la conexión
            $mysqli->close();
        }

        // Si el usuario no ha iniciado sesión y las cookies no son válidas, redirigirlo a la página de inicio de sesión
        if (!isset($_SESSION['user_id'])) {
            header("Location: login.php");
            exit;
        }
    }
}

// Llamada a la función
check_user_logged_in();