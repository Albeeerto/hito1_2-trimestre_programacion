<!DOCTYPE html>
<html>
<head>
    <title>Iniciar sesión</title>
    <!-- CSS de Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Mi Blog</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item ">
                <a class="nav-link" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_post.php">Ver entradas</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php">Crear entradas</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="register.php">Registro</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="login.php">iniciar sesion</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container">
    <h1 class="my-4">Iniciar sesión</h1>
    <form action="login_process.php" method="post">
        <div class="form-group">
            <label for="email">Correo electrónico:</label>
            <input type="email" id="email" name="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Iniciar sesión</button>
        <a href="edit_profile.php" class="btn btn-secondary">Modificar perfil</a>
    </form>
</div>
</div>
<!-- JS de Bootstrap -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>