create database blog;
USE blog;

CREATE TABLE IF NOT EXISTS posts (
                                     id INT AUTO_INCREMENT PRIMARY KEY,
                                     email VARCHAR(255) NOT NULL,
                                     title VARCHAR(255) NOT NULL,
                                     content TEXT NOT NULL,
                                     publish_date DATE NOT NULL,
                                     image TEXT
);

CREATE TABLE IF NOT EXISTS users (
                                     id INT AUTO_INCREMENT PRIMARY KEY,
                                     name VARCHAR(50),
                                     email VARCHAR(50),
                                     password VARCHAR(255)
);